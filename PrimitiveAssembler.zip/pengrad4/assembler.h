
//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.

#ifndef ASSEMBLER_H
#define ASSEMBLER_H
#include <fstream>
#include <sstream>
#include "symboltable.h"
#include "expressioneval.h"

using namespace std;
struct opElement{
int opcode;
int format;
char operation[20];


};

struct NodeTypeO;

typedef NodeTypeO* PointerTypeO;

struct NodeTypeO{
    opElement element;
    PointerTypeO next;
};

class assembler
{
    public:
        assembler(int, char*[]);
        ~assembler();
        void writeOneLine(string[]);
        void writeTwoLine(string []);
        PointerTypeO opHead;
        void objectLiteral();
        ofstream writeFile;
        ofstream objWrite;
        ofstream lstWrite;
        string progName;
        int lnNo;
        int baseAddr;
        int addrLoc;
        int backupLoc;
        int lastObj;
        int boolToInt(bool byte[]);
        stringstream defref;
        stringstream tWrite;
        stringstream realref;
        void litDump(ofstream&);

        pengrad2 y;
        bool fFour;
        void pass2(char []);
        PointerTypeO opSearch(string);
    protected:

    private:
        void opTable();

};

#endif // ASSEMBLER_H
