//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.

#include "symboltable.h"
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <cstring>
#include <cctype>
#include <iomanip>
#include <sstream>
using namespace std;


BSTreeType::BSTreeType()
{
    theTree = NULL;
    entryCounter=0;
    fstream inFile;
    inFile.open("symtable.dat");
if (!inFile){
    cout << "File not found. This table will not be initialized.";}
else{

char symbol[100];
char rflag[100];
char tempInt[20];
ElementType draftF;
draftF.value=0;
draftF.iflag=1;
draftF.mflag=0;
draftF.qflag=0;
while(!inFile.eof()){
inFile>>symbol>>rflag>>tempInt;


strcpy(draftF.symbol, symbol);


if(!isalpha(symbol[0])){
   // cout << "Error: " << symbol << " does not start with a letter, so it is not a valid symbol."<<endl;
    continue;
}
else if (!issymbol(symbol)){
    cout << "Error: " << symbol << " contains non-alphanumeric data, and is invalid."<<endl;

}
else if (strlen(symbol)>16){
    cout << "Error: " << symbol << " contains more than 16 characters."<<endl;
    continue;
}
else if (search(draftF, 1))
{
   cout << "Error: " << symbol << " already exists in the program."<<endl;
    continue;
}
else{strcpy(draftF.symbol, symbol);
        draftF.symbol[6]='\0';}

for (int i=0; rflag[i] != '\0'; i++){

    rflag[i]=toupper(rflag[i]);
}

if((strcmp(rflag,"TRUE")==0) || (strcmp(rflag, "1")==0)){draftF.rflag = true;}
else if ((strcmp(rflag,"FALSE")==0) || (strcmp(rflag, "0")==0)){draftF.rflag = false;}
else{
        cout << "Error: the Rflag value "<< rflag << " from symbol" << symbol << " can't be read." << endl;

        continue;}

if ((atoi(tempInt)==0) && strcmp(tempInt,"0")==0){cout<<"Error: the integer "<< tempInt  << " from " << symbol <<" is not a valid integer." << endl;
continue;}
else if (strchr(tempInt, '.')){ cout << "Error: the integer "<< tempInt << " from " <<symbol << " is not an integer."<<endl;}
else{draftF.value = atoi(tempInt);}

insert(draftF);
}}
inFile.close();
}


BSTreeType::BSTreeType(const BSTreeType & model)
{
theTree = NULL;
copy (model.theTree);
}


BSTreeType::~BSTreeType()
{
destroy(theTree);
}


void BSTreeType::insert (const ElementType element){

insert(theTree, element);
}

void BSTreeType::remove (const ElementType element){
remove(theTree, element);
}


PointerType BSTreeType::search (ElementType key, bool mute=0)const{
key.symbol[6]='\0';

return search (theTree ,key, mute);

}




void BSTreeType::inOrderView (ofstream& lst){
//cout<<endl<<endl;
//cout << setw(7) << "Symbol"<< setw(6) << "Value" << setw(6)<< "RFlag"<< setw(6)<< "IFlag" << setw(6) << "Mflag" << endl << endl;
entryCounter=0;
inOrderView(theTree, lst);
}



void BSTreeType::copy (const PointerType place){

if (place != NULL){
insert (place->element);

copy (place->left);
copy (place->right);
}

}


void BSTreeType::destroy (PointerType & current){
if (current == NULL){}
else  {
    destroy(current->left);
    destroy(current->right);
    delete current;
     current=NULL;
}}


void BSTreeType::insert(PointerType &place, const ElementType element){

if (place == NULL){
    place = new (std::nothrow) NodeType;
    if (place == NULL){
        cout << "Error in adding to the tree, the tree is currently full."<<endl;
        cout << "This function will exit, as it cannot operate"<<endl;
    }
    else{
    place->element=element;
    place->element.symbol[6]='\0';
    place->left = NULL;
    place->right = NULL;
    }
}

else if (strcmp(element.symbol, place->element.symbol) < 0){
insert (place->left, element);
}
else if (strcmp(element.symbol, place->element.symbol) > 0){
insert (place->right, element);
}
else{
cout << "The value was not inserted into the tree, as the value was already placed in the tree previously.";
place->element.mflag=1;
}
}


void BSTreeType::remove(PointerType &place, const ElementType element){

if (place == NULL){

    cout << "The element could not be found in the tree. Nothing will be returned."<< endl;
}
else if (strcmp(place->element.symbol, element.symbol)==0){
    removeNode(place);
}
else if (strcmp(place->element.symbol, element.symbol) > 0){
    remove(place->left, element);
}
else if (strcmp(place->element.symbol, element.symbol) < 0){
    remove(place->right, element);
}

}


void BSTreeType::removeNode(PointerType &place){
PointerType temp=NULL;

if (place->left==NULL && place->right==NULL){

   delete place;
   place=NULL;
}
else if (place->left==NULL){
temp = place;
place = place->right;

delete temp;
temp=NULL;
}
else if (place->right==NULL){
temp = place;
place = place->left;

delete temp;
temp=NULL;
}
else{
    findMinNode (place->right, temp);
    place->element=temp->element;
    delete temp;
    temp=NULL;
}
}
bool BSTreeType::issymbol(const char symbol[]){

for(int i=0; symbol[i]!='\0'; i++){
    if(!isalpha(symbol[i])&& !isdigit(symbol[i])){
        return 0;
    }
}
return 1;
}
void BSTreeType::findMinNode(PointerType &place, PointerType &temp){

if (place->left == NULL){
    temp=place;
    place=place->right;
    temp->left = NULL;
}
else{
    findMinNode(place->left, temp);
}
}

PointerType BSTreeType::search(const PointerType searchnode, const ElementType key, bool mute)const{

if (searchnode==NULL){
   if(mute==0){cout << "Error: The value "<< key.symbol <<" could not be found in the tree."<<endl;}

    return 0;
}

if(strcmp(searchnode->element.symbol, key.symbol)==0){
     if(mute==1){searchnode->element.mflag=true;}
     else if (mute==0){cout <<  setw(7)<< searchnode->element.symbol << setw(6)<< searchnode->element.value << setw(6)<< searchnode->element.rflag << setw(6)<< searchnode->element.iflag << setw(6)<<searchnode->element.mflag << endl;}

    return searchnode;
}

else if (strcmp(searchnode->element.symbol, key.symbol) < 0){

    return search(searchnode->right, key, mute);
}
else if (strcmp(searchnode->element.symbol, key.symbol) > 0){

    return search(searchnode->left, key, mute);
}
else {return 0;}
}

void BSTreeType::inOrderView(const PointerType place, ofstream& lst){


if (place != NULL){

inOrderView (place->left, lst);
lst <<  setw(7)<< place->element.symbol << setw(6)<< place->element.value << setw(6)<< place->element.rflag << setw(6)<< place->element.iflag << setw(6)<<place->element.mflag << endl;
cout <<  setw(7)<< place->element.symbol << setw(6)<< place->element.value << setw(6)<< place->element.rflag << setw(6)<< place->element.iflag << setw(6)<<place->element.mflag << endl;
entryCounter++;

/*if (entryCounter % 22 == 0 && entryCounter !=0){
    cin.ignore();
   cout << setw(7) << "Symbol"<< setw(6) << "Value" << setw(6)<< "RFlag"<< setw(6)<< "IFlag" << setw(6) << "Mflag" << endl << endl;
    }*/


inOrderView (place->right, lst);


}





}
