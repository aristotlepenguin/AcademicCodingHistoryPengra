//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.


#include "expressioneval.h"
#include "symboltable.h"
#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <cctype>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;
pengrad2::pengrad2()
{
x=x;

lHead=NULL;




   /* theHead = NULL;
    lHead=NULL;
    entryCounter=0;
    litCount=0;
    fstream inFile;
    inFile.open("symtable.dat");
if (!inFile){
    cout << "File not found. This table will not be initialized.";}
else{

char symbol[100];
char rflag[100];
char tempInt[20];
ExpressionType draftF;
draftF.value=0;
draftF.iflag=1;
draftF.mflag=0;
while(!inFile.eof()){
inFile>>symbol>>rflag>>tempInt;


strcpy(draftF.symbol, symbol);


if(!isalpha(symbol[0])){
    cout << "Error: " << symbol << " does not start with a letter, so it is not a valid symbol."<<endl;
    continue;
}
else if (!isSymbol(symbol)){
    cout << "Error: " << symbol << " contains non-alphanumeric data, and is invalid."<<endl;
continue;
}
else if (strlen(symbol)>16){
    cout << "Error: " << symbol << " contains more than 16 characters."<<endl;
    continue;
}
else if (search(draftF, 1))
{
   cout << "Error: " << symbol << " already exists in the program."<<endl;
    continue;
}
else{strcpy(draftF.symbol, symbol);
        draftF.symbol[6]='\0';}

for (int i=0; rflag[i] != '\0'; i++){

    rflag[i]=toupper(rflag[i]);
}

if((strcmp(rflag,"TRUE")==0) || (strcmp(rflag, "1")==0)){draftF.rflag = true;}
else if ((strcmp(rflag,"FALSE")==0) || (strcmp(rflag, "0")==0)){draftF.rflag = false;}
else{
        cout << "Error: the Rflag value "<< rflag << " from symbol" << symbol << " can't be read." << endl;

        continue;}

if ((atoi(tempInt)==0) && strcmp(tempInt,"0")==0){cout<<"Error: the integer "<< tempInt  << " from " << symbol <<" is not a valid integer." << endl;
continue;}
else if (strchr(tempInt, '.')){ cout << "Error: the integer "<< tempInt << " from " <<symbol << " is not an integer."<<endl;
continue;}
else{draftF.value = atoi(tempInt);}

insert(draftF);
}}
inFile.close();*/
}

pengrad2::~pengrad2()
{/*
PointerTypeE navPtr;
   while(theHead!=NULL){
   navPtr=theHead;
   theHead=navPtr->next;
   delete navPtr;}
*/
}


void pengrad2::insert (const ExpressionType elementIns){
    /*
PointerTypeE navPtr, temp;
navPtr=theHead;
while (1){
    if(navPtr==NULL){
        theHead= new (std::nothrow) NodeTypeE;
       theHead->element=elementIns;
       theHead->next=NULL;
       break;
    }
    else if (navPtr->next == NULL){
        navPtr->next= new(std::nothrow) NodeType;
        navPtr->next->element=elementIns;
        navPtr->next->next=NULL;
        break;

    }
    else if (strcmp(navPtr->next->element.symbol, elementIns.symbol) > 0){
        temp=new (std::nothrow) NodeType;
        temp->next=navPtr->next;
        navPtr->next=temp;
        temp->element=elementIns;
        break;
    }
     else if (strcmp(navPtr->next->element.symbol, elementIns.symbol) < 0){
        navPtr=navPtr->next;
    }
}
*/
}


/*PointerType pengrad2::search (ElementType searchItem, bool mute){

PointerType navPtr=theHead;
searchItem.symbol[6]='\0';
while (1){
if(navPtr==NULL){
  if(mute==0){
  cout<<"The value can't be found. Returning zero."; }
    return 0;
}
else if(strcmp(navPtr->element.symbol, searchItem.symbol)==0){
    if(mute==1){navPtr->element.mflag=true;}
    return navPtr;
}
else{
    navPtr=navPtr->next;

}
}
}*/

bool pengrad2::isSymbol(const char symbol[], char single){
if(single=='\0'){
for(int i=0; symbol[i]!='\0'; i++){
    if(!isalpha(symbol[i])&& !isdigit(symbol[i])){
        return 0;
    }
}
return 1;
}
else{

    if(!isalpha(single)&& !isdigit(single)){
        return 0;
}
return 1;
}}
/*
void pengrad2::view(){

PointerType navPtr;
navPtr=theHead;
while(navPtr!=NULL){
        cout<<navPtr->element.symbol<<endl;
        navPtr=navPtr->next;
}

}*/

dispShell pengrad2::evalTree(char subject[]){
    ElementType command[2];
    char operate[2];
    operate[0]=0;
    operate[1]=0;
    int cCount=0;
    int oCount=0;
    dispShell a;
    a.value=0;
    a.relocatable=0;
    a.direct=0;
    a.indirect=0;
    a.immediate=0;
    a.indexed=0;
    a.success=0;
    int z=0;

if(!isSymbol(&subject[0], subject[0])){
    operate[0]=subject[0];

    z++;
    if(operate[0]=='='){}//PSEUDOCODE FOR LITERAL INSERTION
}
while (subject[z]!='\0'){
    if(isSymbol(&subject[z], subject[z])){
        //strncat(command[cCount].symbol, &subject[z], 1);
        command[cCount].symbol[oCount]=subject[z];

        //cout<<command[cCount].symbol;
        oCount++;
    }
    else if(subject[z]==','){
        a.indexed=1;
        break;
    }
    else{operate[1]=subject[z];
            command[cCount].symbol[oCount]='\0';
            cCount++;
            oCount=0;}

 z++;
}
command[cCount].symbol[oCount]='\0';
//cout<<command[0].symbol;
//cout<<command[1].symbol;
if(stringNumC(subject)){//Check if it is a pure number
    a.value=atoi(subject);
    a.immediate=1;
}
else if(operate[1]){
       // PointerType ghost1, ghost2;
   PointerType ghost1=x.search(command[0], true);
    PointerType ghost2=x.search(command[1], true);

   if(stringNumC(command[1].symbol) && stringNumC(command[0].symbol)){
     if(operate[1]=='+'){
        a.value=atoi(command[0].symbol)+atoi(command[1].symbol);
        a.relocatable=0;
        }
        else if(operate[1]=='-'){
            a.value=atoi(command[0].symbol)-atoi(command[1].symbol);
        a.relocatable=0;
        }
        else if(operate[1]==','){
            a.value=atoi(command[0].symbol);
            a.relocatable=0;
            a.indexed=1;
        }
   }
    else if(stringNumC(command[1].symbol)){
            if(operate[1]=='+'){
        a.value=ghost1->element.value+atoi(command[1].symbol);
        a.relocatable=ghost1->element.rflag;
        }
        else if(operate[1]=='-'){
            a.value=ghost1->element.value-atoi(command[1].symbol);
            a.relocatable=ghost1->element.rflag;
        }
        else if(operate[1]==','){
            a.value=ghost1->element.value;
            a.relocatable=ghost1->element.rflag;
        }
    }
    else if(stringNumC(command[0].symbol)){


          if(operate[1]=='+'){
        a.value = atoi(command[0].symbol) + ghost2->element.value;
        a.relocatable=ghost2->element.rflag;
        }
        else if(operate[1]=='-'){
            a.value=atoi(command[0].symbol)-ghost2->element.value;
            a.relocatable=ghost2->element.rflag;
        }
        else if(operate[1]==','){
            a.value=atoi(command[0].symbol);
            a.relocatable=0;
            a.indexed=1;
        }
    }
    else if(x.search(command[0], 1)&& x.search(command[1], 1)) {
         if(operate[1]=='+'){
        a.value=ghost1->element.value+ghost2->element.value;
if(ghost1->element.rflag!=ghost2->element.rflag){a.relocatable=1;}
        }
        else if(operate[1]=='-'){
          a.value=ghost1->element.value+ghost2->element.value;
        if(ghost1->element.rflag!=ghost2->element.rflag){a.relocatable=1;}
        }
        else if(operate[1]==','){
           a.value=ghost1->element.value;

            a.indexed=1;
        }
    }
    else{

    }

}
else if(command[0].symbol && !command[1].symbol){
    a.value=x.search(command[0], 1)->element.value;

}
if(operate[0]=='#'){
    a.immediate=1;
}
else if(operate[0]=='@'){

a.indirect=1;
}
if(!(a.indirect || a.immediate)){
    a.direct=1;
}

if(subject[0]=='='){
    literal(subject);
    return a;
}
else if(operate[0]=='@' && stringNumC(command[0].symbol)&& cCount==0){
    cout<< "Error: indirect addressing can't be used with immediate integer values."<<endl;
}
else if(operate[0]!='#' && operate[0]!= '@' && operate[0]){
    cout<<"Error: invalid first operand."<<endl;
}
else if((a.indexed)&&(a.immediate||a.indirect)){
    cout<<"Error: indexed addressing on \n"<< command[0].symbol <<" \ncan't be used with either indirect or immediate addressing."<<endl;
}
else if(operate[0]=='@'&& stringNumC(command[0].symbol)&&stringNumC(command[1].symbol)){
    cout<< "Error: indirect addressing on integer "<< command[0].symbol << " can't be used."<<endl;
}
else if (subject[1]=='@' || subject[1]=='#'){
    cout<< "Error: multiple addressing prefixes can't be used.";
}
else if(!stringNumC(command[0].symbol)&& !x.search(command[0],1)){
    //cout<<"The first symbol input can't be recognized as a symbol or an integer."<<endl;
}
else if (cCount==0 || operate[1]==39){
        if(stringNumC(command[0].symbol)){
            a.relocatable=0;
            a.value=atoi(command[0].symbol);
        }
        else{
        a.value=x.search((command[0]),1)->element.value;
 a.relocatable=x.search((command[0]),1)->element.rflag;}
    //cout << setw(20) << subject<< setw(9) << a.value << setw(9)<< a.relocatable<< setw(9)<< a.direct << setw(9) << a.indirect;
      // cout  << setw(10) << a.immediate<< setw(9)<< a.indexed <<endl;

}
else if(operate[1]!='+'&& operate[1]!='-'){
 cout<<"Error: invalid second operand."<<endl;
}
else if (stringNumC(command[0].symbol) && !stringNumC(command[1].symbol)){
    if(x.search(command[1], 1)->element.rflag==1){
        cout<<"Error:Rflag error, can't subtract two symbols when only the right flag equals 1" <<endl;
    }
else{
    //cout << setw(20) << subject<< setw(9) << a.value << setw(9)<< a.relocatable<< setw(9)<< a.direct << setw(9) << a.indirect;
      //cout  << setw(10) << a.immediate<< setw(9)<< a.indexed <<endl;
}
}
else if(stringNumC(command[1].symbol)&& !stringNumC(command[0].symbol)){

   // cout << setw(20) << subject<< setw(9) << a.value << setw(9)<< a.relocatable<< setw(9)<< a.direct << setw(9) << a.indirect;
    //   cout  << setw(10) << a.immediate<< setw(9)<< a.indexed <<endl;

}
else if(!stringNumC(command[1].symbol)&& x.search(command[1],1)==0){
    cout<<"The second symbol input can't be recognized as a symbol or an integer."<<endl;
}
else if(stringNumC(command[0].symbol)&&stringNumC(command[1].symbol)){
        a.direct=0;
        a.immediate=1;
    // cout << setw(20) << subject<< setw(9) << a.value << setw(9)<< a.relocatable<< setw(9)<< a.direct << setw(9) << a.indirect;
    //   cout  << setw(10) << a.immediate<< setw(9)<< a.indexed <<endl;
}
else if(x.search(command[0], 1)->element.rflag && x.search(command[1], 1)->element.rflag && operate[1]=='+'){
    cout<<"Error:Rflag error, can't add two symbols when each of their rflags equals 1"<<endl;
}
else if(!x.search(command[0], 1)->element.rflag && x.search(command[1], 1)->element.rflag && operate[1]=='-'){
    cout<<"Error:Rflag error, can't subtract two symbols when only the right flag equals 1"<<endl;
}

else if (stringNumC(command[0].symbol)&& operate[1]=='-' && x.search(command[1], 1)->element.rflag==1){
    cout<<"Error:Rflag error: can't subtract a relocatable from an integer."<<endl;
}
else{

    //   cout << setw(20) << subject<< setw(9) << a.value << setw(9)<< a.relocatable<< setw(9)<< a.direct << setw(9) << a.indirect;
     //  cout  << setw(10) << a.immediate<< setw(9)<< a.indexed <<endl;
}
a.success=1;
return a;
}
void pengrad2::literal(const char subject[]){
ExpressionType literal;
int litLengthC=0;
literal.value=0;

char mid[100];
if(subject[2]==39){

        for(int q=3; subject[q]!=39; q++){
           mid[q-3]=subject[q];
            litLengthC++;
            if(subject[q+1]==39){
                mid[q-2]='\0';
            }
            }

        }
strcpy(literal.litText, mid);

       strcpy(literal.symbol, subject);
       if(toupper(subject[1])=='C'){
       literal.rflag=1;}
       else if (toupper(subject[1])!='X'){
        cout<<"Error: invalid literal syntax."<<endl;
       }
       literal.value=litCount;
       litCount++;

if(litLengthC%2!=0){
    litLengthC++;
}
if(subject[1]=='C'){
 literal.litLength=litLengthC;
}
else{literal.litLength=(litLengthC/2);}
PointerTypeE navPtr;
navPtr=lHead;

while(navPtr!=NULL){

        if(strcmp(navPtr->element.symbol, literal.symbol)==0){
           return;}
        navPtr=navPtr->next;

}

navPtr=lHead;
while (1){
    if(navPtr==NULL){
        lHead= new (std::nothrow) NodeTypeE;
       lHead->element=literal;
       lHead->next=NULL;
       break;
    }
    else if (navPtr->next == NULL){
        navPtr->next= new(std::nothrow) NodeTypeE;
        navPtr->next->element=literal;
        navPtr->next->next=NULL;
        break;

    }
     else {
        navPtr=navPtr->next;
    }


}

}

bool pengrad2::stringNumC(char subject[]){
    int i=0;
while(subject[i] != '\0'){
    if(!isdigit(subject[i])){
        return 0;
    }
    i++;
}
if(i!=0){
return 1;}
else{return 0;}
}
 void pengrad2::litView(){
PointerTypeE navPtr;
navPtr=lHead;
stringstream ss;
string valueProp="";
int printCount=0;
while(navPtr!=NULL){
if(printCount>17){
    printCount=0;
    cin.ignore();
    cout<< endl << endl <<setw(42) << "LITERAL TABLE\n\n";
  cout << setw(20) << "NAME" << setw(20)<< "VALUE"<< setw(9)<< "LENGTH" <<setw(9) << "ADDRESS"<<endl;
}

cout<< setw(20) << navPtr->element.symbol << setw(20);

if(toupper(navPtr->element.symbol[1])=='X'){
for(int s=0; navPtr->element.litText[s]!='\0'; s++){
        ss<<navPtr->element.litText[s];

}
valueProp=ss.str();
}
else if (toupper(navPtr->element.symbol[1])=='C'){

    for(int s=0; navPtr->element.litText[s]!='\0'; s++){
        ss<< hex <<int(navPtr->element.litText[s]);
}
valueProp=ss.str();
}
else{navPtr=navPtr->next;
        continue;}

cout<<valueProp <<setw(9)<< navPtr->element.litLength << setw(9) << navPtr->element.value<<endl;
printCount++;
ss.str("");
navPtr=navPtr->next;
}
return;

 }


 PointerTypeE pengrad2::litReturn(const char searchOne[]){

PointerTypeE navPtr=lHead;


while (1){
if(navPtr==NULL){

    return 0;
}
else if(strcmp(navPtr->element.symbol, searchOne)==0){

    return navPtr;
}
else{
    navPtr=navPtr->next;

}
}


/*
stringstream ss;
string valueProp="";
int printCount=0;
while(navPtr!=NULL){
if(printCount>17){
    printCount=0;
    cin.ignore();
    cout<< endl << endl <<setw(42) << "LITERAL TABLE\n\n";
  cout << setw(20) << "NAME" << setw(20)<< "VALUE"<< setw(9)<< "LENGTH" <<setw(9) << "ADDRESS"<<endl;
}

cout<< setw(20) << navPtr->element.symbol << setw(20);

if(toupper(navPtr->element.symbol[1])=='X'){
for(int s=0; navPtr->element.litText[s]!='\0'; s++){
        ss<<navPtr->element.litText[s];

}
valueProp=ss.str();
}
else if (toupper(navPtr->element.symbol[1])=='C'){

    for(int s=0; navPtr->element.litText[s]!='\0'; s++){
        ss<< hex <<int(navPtr->element.litText[s]);
}
valueProp=ss.str();
}
else{navPtr=navPtr->next;
        continue;}

cout<<valueProp <<setw(9)<< navPtr->element.litLength << setw(9) << navPtr->element.value<<endl;
printCount++;
ss.str("");
navPtr=navPtr->next;
}
return;
*/
 }
