//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.

#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H
#include <fstream>

using namespace std;

struct ElementType{
char symbol[100];
bool rflag;
int value;
bool iflag;
bool mflag;
bool qflag;
}; //
struct NodeType;

typedef NodeType* PointerType;

struct NodeType{
    ElementType element;
    PointerType left;
    PointerType right;
};

class BSTreeType
{
    public:

	    BSTreeType();

        BSTreeType(const BSTreeType &);
        ~BSTreeType();//

		void insert (const ElementType);

        void remove (const ElementType);//

        PointerType search(ElementType, bool) const;//


        void inOrderView (ofstream&);//

        bool issymbol (const char[]);
		int entryCounter;
		void insert (PointerType &, const ElementType);//
    private:
        PointerType theTree;//

        void copy(const PointerType);//
        void destroy(PointerType &);//
        void removeNode(PointerType &);//

        void findMinNode(PointerType &, PointerType &);//

        void remove(PointerType&, const ElementType);//
        PointerType search(const PointerType, const ElementType, bool mute) const;//

        void inOrderView (const PointerType, ofstream&) ;//



};





#endif // SYMBOLTABLE_H
