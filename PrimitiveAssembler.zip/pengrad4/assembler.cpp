//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.

#include "assembler.h"
#include <fstream>

#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;

assembler::assembler(int argc, char* argv[])
{
    opHead=NULL;
    lnNo=0;
    baseAddr=0;
    addrLoc=0;
char fileName[40];
    opTable();
    fstream readFile;
    if(argc==1){
    cout<<"Please enter a program to execute.";
    cin>>fileName;
    readFile.open(fileName);
    }
    else if(argc==2){
        readFile.open(argv[1]);
        strcpy(fileName, argv[1]);
    }
    else{cout<<"Error: invalid command prompt.";
            return;}
    if(!readFile){
        cout<<"File not found. This program will not be executed.";
        return;
    }
    int r;
    string center;
for(r=0; fileName[r]!='.' && fileName[r]!='\0'; r++){

}
fileName[r]='.';
fileName[r+1]='i';
fileName[r+2]='n';
fileName[r+3]='t';
fileName[r+4]='\0';
writeFile.open(fileName);

string midLine;
string argList[3];
while (!readFile.eof()){
getline(readFile, center);
stringstream ss;
ss.str(center);
fFour=0;
argList[0]="";
argList[1]="";
argList[2]="";
for(int m=0; !ss.eof() && m<3; m++){
ss>>midLine;
if(midLine[0]=='.'){
    break;
}
if(midLine[0]=='+'){
    midLine.erase(0, 1);
    fFour=1;
}
if(midLine[0]=='='){
    y.literal(midLine.c_str());
    break;
}
argList[m] = midLine;

}

if(midLine[0]=='='){
if(argList[0]!="LDA" && argList[0]!="*"){
ElementType draftH;
strcpy(draftH.symbol, argList[0].c_str());
draftH.rflag=0;
draftH.value=addrLoc;
draftH.iflag=1;
draftH.mflag=0;
draftH.qflag=0;
y.x.insert(draftH);
}
}
else if(!argList[0].empty()){
 writeOneLine(argList);}
 ss.clear();
}

readFile.close();
cout<<endl<<endl<<"PASS 2" <<endl<<endl;
pass2(fileName);

}

assembler::~assembler()
{

   writeFile.close();
}
void assembler::opTable(){
fstream opFile;
opFile.open("operations.dat");

while (!opFile.eof()){
PointerTypeO navPtr;
opElement draftG;
navPtr=opHead;
char middle[40];
opFile>>middle;
strcpy(draftG.operation, middle);

opFile>>middle;
draftG.format=atoi(middle);
opFile>>middle;
draftG.opcode=strtol(middle, NULL, 16);

while (1){
    if(navPtr==NULL){
        opHead= new (std::nothrow) NodeTypeO;
       opHead->element=draftG;
       opHead->next=NULL;
       break;
    }
    else if (navPtr->next == NULL){
        navPtr->next= new(std::nothrow) NodeTypeO;
        navPtr->next->element=draftG;
        navPtr->next->next=NULL;
        break;

    }
     else {
        navPtr=navPtr->next;
    }


}

}

opFile.close();
}


void assembler::writeOneLine(string argList[]){

    int dev=0;


    if(argList[1]=="START"){
            addrLoc=atoi(argList[dev+1].c_str());

      writeFile<< lnNo << "\t" ;
      writeFile<< setfill('0') << setw(5)<< hex << addrLoc << "\t";
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout<< lnNo << "\t" ;
      cout<< setfill('0') << setw(5)<< hex << addrLoc << "\t";
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
lnNo++;
    }


    if(!argList[2].empty()){
       dev=1;
ElementType draftH;
strcpy(draftH.symbol, argList[0].c_str());
draftH.rflag=0;
draftH.value=addrLoc;
draftH.iflag=1;
draftH.mflag=0;
draftH.qflag=0;
y.x.insert(draftH);


    }
else if(opSearch(argList[1])){
    dev=1;
    ElementType draftH;
strcpy(draftH.symbol, argList[0].c_str());
draftH.rflag=0;
draftH.value=addrLoc;
draftH.iflag=1;
draftH.mflag=0;
draftH.qflag=0;
y.x.insert(draftH);
}
else{dev=0;}


  if(argList[dev]=="START"){


    }
 else if(argList[dev]=="BASE"){
    baseAddr=addrLoc;


    writeFile<< lnNo << "\t" ;
    writeFile<< setfill('0') << setw(5) << hex<< addrLoc << "\t";
    cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
    }
else if(argList[dev]=="EXTDEF"){
    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";
    cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";
    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}
        lnNo++;

    }
else if(argList[dev]=="END"){

        cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
      litDump(writeFile);
    }
    else if(argList[dev]=="BYTE"){



    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";
cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
      addrLoc=addrLoc+1;
    }
    else if(argList[dev]=="WORD"){



    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";
    cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
      addrLoc=addrLoc+3;
    }
    else if(argList[dev]=="RESW"){



    writeFile<< lnNo << "\t";
    writeFile<< setfill('0') << setw(5)<< hex << addrLoc << "\t";
    cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
      addrLoc = addrLoc + (atoi(argList[dev+1].c_str())*3);
    }
        else if(argList[dev]=="*"){

    writeFile<< lnNo << "\t" << setfill('0') << setw(5)<< hex << addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
     y.literal(argList[dev+1].c_str());
     addrLoc = addrLoc + y.litReturn(argList[dev+1].c_str())->element.litLength;

    }
    else if(argList[dev]=="RESB"){



    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";
    cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;
      addrLoc = addrLoc + (atoi(argList[dev+1].c_str()));
    }
        else if(argList[dev]=="EXTREF"){

    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";
    cout<< lnNo << "\t" ;
    cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}

      lnNo++;

      int newPos=0;
      ElementType draftB;
      draftB.iflag=1;
      draftB.mflag=0;
      draftB.value=0;
      draftB.rflag=1;
      draftB.qflag=1;

      for(unsigned int e=0; e<argList[dev+1].length(); e++){

    if(argList[dev+1][e]==','){
        draftB.symbol[newPos]='\0';
        newPos=0;
        y.x.insert(draftB);
    }
    else{
        draftB.symbol[newPos]=argList[dev+1][e];
        newPos++;
    }

      }
      draftB.symbol[newPos]='\0';
      y.x.insert(draftB);
    }
        else if(argList[dev]=="EQU"){


    writeFile<< lnNo << "\t";
    writeFile << setfill('0') << setw(5) << hex << addrLoc << "\t";
    cout<< lnNo << "\t";
   cout << setfill('0') << setw(5) << hex << addrLoc << "\t";

    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t\t" <<argList[1] << endl;
    cout << "\t\t"<< argList[0] <<"\t" <<argList[1] << endl;}
      lnNo++;

      ElementType draftL;
      strcpy(draftL.symbol, argList[0].c_str());
      char mid3[40];
      strcpy(mid3, argList[2].c_str());
      if (strcmp(mid3, "*")==0){
        y.x.search(draftL,1)->element.value=addrLoc;
      }
      else{y.x.search(draftL,1)->element.value=y.evalTree(mid3).value;}

      //atoi(argList[2].c_str());
    }

    else if (opSearch(argList[dev])){

         writeFile<< lnNo << "\t";
         writeFile<< setfill('0') << setw(5) << hex << addrLoc << "\t";
         cout<< lnNo << "\t" ;
        cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";
   if(!fFour){
    if(dev==1){
      writeFile << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< argList[0] <<"\t\t" <<argList[1] << endl;
        cout << "\t\t"<< argList[0] <<"\t\t" <<argList[1] << endl;}
   }
    else{
    if(dev==1){
      writeFile << "+" << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;
      cout<< "+" << argList[0] <<"\t" <<argList[1] << "\t" << argList[2] << endl;}
    else{
        writeFile << "\t\t"<< "+" <<argList[0] <<"\t\t" <<argList[1] << endl;
        cout << "\t\t"<< "+" <<argList[0] <<"\t\t" <<argList[1] << endl;}
   }


    addrLoc = addrLoc + opSearch(argList[dev])->element.format;
    if(fFour==1){
        addrLoc++;
    }
    lastObj=addrLoc;
      lnNo++;

    }
    else{
        //cout << "Error: invalid operation.";
    }

    }


PointerTypeO assembler::opSearch(string finder){

PointerTypeO navPtr=opHead;


while (1){
if(navPtr==NULL){

    return 0;
}
else if(strcmp(navPtr->element.operation, finder.c_str())==0){

    return navPtr;
}
else{
    navPtr=navPtr->next;

}
}


}

int assembler::boolToInt(bool byte[]){

if(!byte[0] && !byte[1] && !byte[2] && !byte[3]){
return 0;}
else if(!byte[0] && !byte[1] && !byte[2] && byte[3]){
return 1;}
else if(!byte[0] && !byte[1] && byte[2] && !byte[3]){
return 2;}
else if(!byte[0] && !byte[1] && byte[2] && byte[3]){
return 3;}
else if(!byte[0] && byte[1] && !byte[2] && !byte[3]){
return 4;}
else if(!byte[0] && byte[1] && !byte[2] && byte[3]){
return 5;}
else if(!byte[0] && byte[1] && byte[2] && !byte[3]){
return 6;}
else if(!byte[0] && byte[1] && byte[2] && byte[3]){
return 7;}
else if(byte[0] && !byte[1] && !byte[2] && !byte[3]){
return 8;}
else if(byte[0] && !byte[1] && !byte[2] && byte[3]){
return 9;}
else if(byte[0] && !byte[1] && byte[2] && !byte[3]){
return 10;}
else if(byte[0] && !byte[1] && byte[2] && byte[3]){
return 11;}
else if(byte[0] && byte[1] && !byte[2] && !byte[3]){
return 12;}
else if(byte[0] && byte[1] && !byte[2] && byte[3]){
return 13;}
else if(byte[0] && byte[1] && byte[2] && !byte[3]){
return 14;}
else if(byte[0] && byte[1] && byte[2] && byte[3]){
return 15;}
else{cout<<"You done goofed, son.";}

return 0;
}
void assembler::pass2(char readFile[]){
fstream intRead;
intRead.open(readFile);
if(!intRead){
cout<<"Error: intermediate file can't be found.\n";
}

//y.x.inOrderView();
int q;
for(q=0; readFile[q]!='.' && readFile[q]!='\0'; q++){

}
readFile[q]='.';
readFile[q+1]='l';
readFile[q+2]='s';
readFile[q+3]='t';
readFile[q+4]='\0';

lstWrite.open(readFile);

readFile[q]='.';
readFile[q+1]='o';
readFile[q+2]='b';
readFile[q+3]='j';
readFile[q+4]='\0';

objWrite.open(readFile);
string lgLine;
string lineArgs[5];
bool firstTime=1;



while (!intRead.eof()){
getline(intRead, lgLine);
stringstream ss;
ss.str(lgLine);
fFour=0;
lineArgs[0]="";
lineArgs[1]="";
lineArgs[2]="";
lineArgs[3]="";
lineArgs[4]="";
string midLine;

for(int m=0; !ss.eof() && m<5; m++){
ss>>midLine;


if(midLine[0]=='+'){
    midLine.erase(0, 1);
    fFour=1;
}

lineArgs[m] = midLine;
if(firstTime){
    objWrite<<"H^"<<lineArgs[0] <<"^000000^"<<setw(6)<<setfill('0') << hex << addrLoc;
    tWrite<<endl<<"T^000000^"<< hex <<lastObj;
    firstTime=0;
}
}
if(!lineArgs[0].empty()){

writeTwoLine(lineArgs);
 ss.clear();

 }
 ss.clear();
}
//tWrite<<endl;
objWrite<<realref.str();
objWrite<<tWrite.str();
objectLiteral();
y.x.inOrderView(lstWrite);

objWrite<<defref.str();
objWrite<<endl <<"E^"<<setw(6)<<setfill('0')<< hex << addrLoc;
objWrite.close();
lstWrite.close();
intRead.close();

}

void assembler::writeTwoLine(string argList[]){
int dev=0;
if(!(argList[4]=="")){
dev=1;
}


lstWrite<< argList[0] << "\t";
lstWrite<< argList[1] << "\t";
cout<< argList[0] << "\t";
cout<< argList[1] << "\t";


if(dev==1){
        if(opSearch(argList[dev+2])&& opSearch(argList[dev+2])->element.format==1){
            lstWrite << argList[2] <<"\t\t" <<argList[3]<<"\t\t";
            cout << argList[2] <<"\t\t" <<argList[3]<<"\t\t";
        }
        else{
lstWrite << argList[2] <<"\t" <<argList[3] << "\t\t" << argList[4];
cout << argList[2] <<"\t" <<argList[3] << "\t\t" << argList[4];
}}
else{
lstWrite << "\t\t"<< argList[2] <<"\t\t" <<argList[3];
cout << "\t\t"<< argList[2] <<"\t\t" <<argList[3];
}

cout<<"\t";
lstWrite<<"\t";

if(opSearch(argList[dev+2])){
        tWrite<<"^";
if(opSearch(argList[dev+2])->element.format==1){

cout<<hex<<opSearch(argList[dev+2])->element.opcode;
lstWrite<<hex<<opSearch(argList[dev+2])->element.opcode;
tWrite<<hex<<opSearch(argList[dev+2])->element.opcode;
}
else if(opSearch(argList[dev+2])->element.format==2){

cout<<hex<<opSearch(argList[dev+2])->element.opcode;
lstWrite<<hex<<opSearch(argList[dev+2])->element.opcode;
tWrite<<hex<<opSearch(argList[dev+2])->element.opcode;

if(argList[dev+3]==""){
cout<<"00";
lstWrite<<"00";
tWrite<<"00";
}
else{
bool onePrint=0;
for (unsigned int y=0; y<argList[dev+3].length(); y++){

if(argList[dev+3][y]==','){onePrint=1;}
else if(argList[dev+3][y]=='A'){
cout<<"0";
lstWrite<<"0";
tWrite<<"0";
}
else if(argList[dev+3][y]=='X'){
cout<<"1";
lstWrite<<"1";
tWrite<<"1";}
else if(argList[dev+3][y]=='F'){
cout<<"6";
lstWrite<<"6";
tWrite<<"6";}
else if(argList[dev+3][y]=='P'){
cout<<"8";
lstWrite<<"8";
tWrite<<"8";
y++;
}
else if(argList[dev+3][y]=='L'){
cout<<"2";
lstWrite<<"2";
tWrite<<"2";}
else if(argList[dev+3][y]=='B'){
cout<<"3";
lstWrite<<"3";
tWrite<<"3";}
else if(argList[dev+3][y]=='S'){
if(argList[dev+3][y+1]=='W'){
cout<<"9";
lstWrite<<"9";
tWrite<<"9";
y++;}
else{
cout<<"4";
lstWrite<<"4";
tWrite<<"4";}}
else if(argList[dev+3][y]=='T'){
cout<<"5";
lstWrite<<"5";
tWrite<<"5";
}
}
if(!onePrint){
cout<<"0";
lstWrite<<"0";
tWrite<<"0";
}}}




else if (opSearch(argList[dev+2])->element.format==3){


stringstream newS;
string code;

bool hexDig[4]={0, 0, 0, 0};
newS<< setw(2) << setfill('0') << hex << opSearch(argList[dev+2])->element.opcode;
newS >> code;
char cStr[40];
for(unsigned int p=0; p<argList[dev+3].length(); p++){
    cStr[p]=argList[dev+3][p];
    if(argList[dev+3].length()==p+1){
        cStr[p+1]='\0';
    }
}

lstWrite<< code[0];
cout << code[0];
tWrite << code[0];
if(code[1]=='0'){hexDig[0]=0;}
else if(code[1]=='4'){hexDig[1]=1;}
else if(code[1]=='8'){hexDig[0]=1;}
else if(code[1]=='c'){hexDig[0]=1; hexDig[1]=1;}

if (y.evalTree(cStr).immediate){
hexDig[3]=1;
}
else if (y.evalTree(cStr).indirect){
hexDig[2]=1;
}
else{
hexDig[3]=1;
hexDig[2]=1;
}
cout<<hex << boolToInt(hexDig);
lstWrite<<hex << boolToInt(hexDig);
tWrite<<hex << boolToInt(hexDig);
for(int z=0; z<4; z++){
hexDig[z]=0;}

if(y.evalTree(cStr).indexed){
hexDig[0]=1;
}
if(y.evalTree(cStr).direct || y.evalTree(cStr).indirect)//PC RELATIVE){
{if (baseAddr && !fFour)//BASE RELATIVE){
{hexDig[1]=1;}
else{
    hexDig[2]=1;}}
if(fFour){
hexDig[3]=1;
hexDig[2]=0;
}
cout<<hex << boolToInt(hexDig);
lstWrite<<hex << boolToInt(hexDig);
tWrite<<hex << boolToInt(hexDig);
char addr[40];
strcpy(addr, stringstream(argList[1]).str().c_str());
if(fFour){
    cout<<setw(5)<<setfill('0')<<hex<< y.evalTree(cStr).value;
    lstWrite<<setw(5)<<setfill('0')<<hex<< y.evalTree(cStr).value;
    tWrite<<setw(5)<<setfill('0')<<hex<< y.evalTree(cStr).value;
    int disp4 =strtol(addr, NULL, 16);

    defref<<endl << "M^" <<setw(6)<<setfill('0')<< hex << disp4+1 << "^05";
}
else if(y.evalTree(cStr).immediate){
    int disp=y.evalTree(cStr).value;
    cout<<setw(3)<<setfill('0')<<hex << disp;
    lstWrite<<setw(3)<<setfill('0')<<hex << disp;
    tWrite<<setw(3)<<setfill('0')<<hex << disp;
}
else if (y.evalTree(cStr).direct || y.evalTree(cStr).indirect){

int disp2 =strtol(addr, NULL, 16);
disp2=disp2+3;
if(fFour){disp2++;}
if(baseAddr){disp2=baseAddr;}
disp2=(y.evalTree(cStr).value)-disp2;
stringstream another;
string disp3;
another<<setw(3)<<setfill('0')<<hex << disp2;
disp3=another.str();
while(disp3.length()>3){
    disp3.erase(0,1);
}
cout<<setw(3)<<setfill('0')<<hex << disp3;
lstWrite<<setw(3)<<setfill('0')<<hex << disp3;
tWrite<<setw(3)<<setfill('0')<<hex << disp3;
}



}

}
else if ((argList[dev+3])=="START"){
    progName=argList[dev+2];
}
else if ((argList[dev+2])=="*"){

tWrite<<endl<<"T^"<<setw(6) << setfill('0')<<argList[1] << "^";
if(argList[dev+3][1]=='C'){
for(unsigned int u=0; u<strlen(y.litReturn(argList[dev+3].c_str())->element.litText); u++){

tWrite<<hex<<int(y.litReturn(argList[dev+3].c_str())->element.litText[u]);

}}
else{
  tWrite<< y.litReturn(argList[dev+3].c_str())->element.litText;
}
}
else if ((argList[dev+2])=="END"){

        char addr2[40];
strcpy(addr2, stringstream(argList[dev+3]).str().c_str());
    backupLoc=addrLoc;
    addrLoc=atoi(addr2);
}
else if((argList[dev+2])=="EXTDEF"){
        char comp[40];
        int newPos=0;
        objWrite<<endl<<"D";
        ElementType draftX;
      for(unsigned int e=0; e<argList[dev+3].length(); e++){

    if(argList[dev+3][e]==','){
        comp[newPos]='\0';
        newPos=0;
        strcpy(draftX.symbol ,comp);
        objWrite<<"^"<<comp;
        objWrite<<"^"<< hex<<setw(6) <<setfill('0') <<y.x.search(draftX, 1)->element.value;
        objWrite<<setfill(' ');
        //y.x.insert(draftB);
    }
    else{
        comp[newPos]=argList[dev+3][e];
        newPos++;
    }

      }
      strcpy(draftX.symbol ,comp);
      objWrite<<"^"<<comp;
objWrite<<"^"<< hex<<setw(6) <<setfill('0') <<y.x.search(draftX, 1)->element.value;
    objWrite<<setfill(' ');

}
else if((argList[dev+2])=="EXTREF"){
        char comp[40];
        int newPos=0;
        realref<<endl<<"R";
        ElementType draftX;
      for(unsigned int e=0; e<argList[dev+3].length(); e++){

    if(argList[dev+3][e]==','){
        comp[newPos]='\0';
        newPos=0;
        strcpy(draftX.symbol ,comp);
        realref<<"^"<<comp;

        //y.x.insert(draftB);
    }
    else{
        comp[newPos]=argList[dev+3][e];
        newPos++;
        if((e+1)==argList[dev+3].length()){
            comp[newPos]='\0';
        }
    }

      }

        realref<<"^"<<comp;


}



lstWrite<<endl;
cout<<endl;

}

void assembler::objectLiteral(){

PointerTypeE navPtr;
navPtr=y.lHead;
stringstream ss;
string valueProp="";
int printCount=0;
cout<< endl << endl <<setw(42) <<setfill(' ')<< "LITERAL TABLE\n\n";
cout << setw(20) <<  "NAME" << setw(20)<< "VALUE"<< setw(9)<< "LENGTH" <<setw(9) << "ADDRESS"<<endl;
lstWrite<< endl << endl <<setw(42) <<setfill(' ')<< "LITERAL TABLE\n\n";
lstWrite << setw(20) <<  "NAME" << setw(20)<< "VALUE"<< setw(9)<< "LENGTH" <<setw(9) << "ADDRESS"<<endl;
while (navPtr!=NULL){

    //cout<<"\t\t\t*\t"<<navPtr->element.symbol << endl;

    //navPtr=navPtr->next;
  /*  if(printCount>17){
    printCount=0;
    cin.ignore();
    cout<< endl << endl <<setw(42) << "LITERAL TABLE\n\n";
  cout << setw(20) << "NAME" << setw(20)<< "VALUE"<< setw(9)<< "LENGTH" <<setw(9) << "ADDRESS"<<endl;
}*/

cout<< setw(20) <<  navPtr->element.symbol << setw(20);
lstWrite<< setw(20) <<  navPtr->element.symbol << setw(20);
if(toupper(navPtr->element.symbol[1])=='X'){
for(int s=0; navPtr->element.litText[s]!='\0'; s++){
        ss<<navPtr->element.litText[s];

}
valueProp=ss.str();
}
else if (toupper(navPtr->element.symbol[1])=='C'){

    for(int s=0; navPtr->element.litText[s]!='\0'; s++){
        ss<< hex <<int(navPtr->element.litText[s]);
}
valueProp=ss.str();
}
else{navPtr=navPtr->next;
        continue;}

cout<<valueProp <<setw(9)<< navPtr->element.litLength << setw(9) << backupLoc<<endl;
lstWrite<<valueProp <<setw(9)<< navPtr->element.litLength << setw(9) << backupLoc<<endl;
printCount++;
ss.str("");
navPtr=navPtr->next;
}
cout<< endl << endl <<setw(42) <<setfill(' ')<< "SYMBOL TABLE\n\n";
lstWrite<< endl << endl <<setw(42) <<setfill(' ')<< "SYMBOL TABLE\n\n";
cout << setw(7) << "Symbol"<< setw(6) << "Value" << setw(6)<< "RFlag"<< setw(6)<< "IFlag" << setw(6) << "Mflag" << endl << endl;
lstWrite << setw(7) << "Symbol"<< setw(6) << "Value" << setw(6)<< "RFlag"<< setw(6)<< "IFlag" << setw(6) << "Mflag" << endl << endl;
//y.x.inOrderView(lstWrite);


return;
}
void assembler::litDump(ofstream& write){

PointerTypeE navPtr;
navPtr=y.lHead;

while (navPtr!=NULL){



 cout<< lnNo << "\t" ;
cout<< setfill('0') << setw(5) << hex<< addrLoc << "\t";

writeFile<< lnNo << "\t";
writeFile << setfill('0') << setw(5)<< hex << addrLoc << "\t";


writeFile << "\t\t"<< "*" <<"\t\t" << navPtr->element.symbol << endl;
cout << "\t\t"<< "*" <<"\t" << navPtr->element.symbol << endl;

lnNo++;
navPtr=navPtr->next;}


    }



