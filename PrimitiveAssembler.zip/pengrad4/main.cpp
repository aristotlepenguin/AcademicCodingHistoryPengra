//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.

#include <iostream>
#include "symboltable.h"
#include "expressioneval.h"
#include "assembler.h"
#include <fstream>
#include <iomanip>
using namespace std;


int main(int argc, char* argv[]){


assembler hatFace(argc, argv);
/*
ElementType searchSend;
int main(int argc, char* argv[])

{
	//BSTreeType b;
//b.inOrderView();
//BSTreeType ix;
pengrad2 c;
fstream exFile;


if(argc==2){
exFile.open(argv[1]);
if(!exFile){
    cout<<"File not found. This table will not be searched.";
    return 0;
}
else{



}}
else if(argc==1){
    char fileNameC[20];
    cout<<"Please enter a literal file to be opened.";
    cin>>fileNameC;
    exFile.open(fileNameC);
    cin.ignore();
       if(!exFile){
    cout<<"File not found. This table will not be searched.";
    return 0;

       }
else{



}
}


 char testRun[100];
 cout << setw(20) << "SUBJECT"<< setw(9) << "VALUE" << setw(9)<< "RFLAG"<< setw(9)<< "DIRECT" << setw(9) << "INDIR";
       cout << setw(10)<< "IMMEDIATE" << setw(9) << "INDEX"<< endl;
       int pCount=0;

 while(!exFile.eof()){
    if(pCount>18){
            pCount=0;

        cin.ignore();
        cout << setw(20) << "SUBJECT"<< setw(9) << "VALUE" << setw(9)<< "RFLAG"<< setw(9)<< "DIRECT" << setw(9) << "INDIR";
       cout << setw(10)<< "IMMEDIATE" << setw(9) << "INDEX"<< endl;
    }
       exFile>>testRun;
       if(c.evalTree(testRun).success){
       pCount++;}
 }
cin.ignore();

cout<< endl << endl <<setw(42) << "LITERAL TABLE\n\n";
  cout << setw(20) << "NAME" << setw(20)<< "VALUE"<< setw(9)<< "LENGTH" <<setw(9) << "ADDRESS"<<endl;
c.litView();

exFile.close();

     return 0;
//YOU MAY NEED A COMMENT BLOCK HERE
    if(argc==2){


cout << endl << "Searching..." << endl;
cout << setw(7) << "Symbol"<< setw(6) << "Value" << setw(6)<< "RFlag"<< setw(6)<< "IFlag" << setw(6) << "Mflag" << endl << endl;

    fstream searchFile;
    searchFile.open(argv[1]);
    if (!searchFile){
    cout << "File not found. This table will not be searched.";}
    else{
    while (!searchFile.eof()){
    searchFile>>searchSend.symbol;
    searchSend.symbol[6]='\0';
    if(!buddy.issymbol(searchSend.symbol)){cout<<"Error: the symbol "<< searchSend.symbol <<" should contain only letters and digits. ";}
else{
    buddy.search(searchSend, false);}
}}}
else if (argc==1){

char fileNameC[20];
    buddy.inOrderView();
    cout << "Please enter a search file to be opened.";
    cin >> fileNameC;
       fstream searchFile;
    searchFile.open(fileNameC);
    if (!searchFile){
    cout << "File not found. This table will not be initialized.";}
else{

    while (!searchFile.eof()){
    searchFile>>searchSend.symbol;
    searchSend.symbol[6]='\0';
    if(!buddy.issymbol(searchSend.symbol)){cout<<"Error: the symbol "<< searchSend.symbol <<" should contain only letters and digits. ";}
else{
    buddy.search(searchSend, false);}



}

}}
else{
cout<< "The command line input has multiple strings, and cannot be read."<<endl;
cout<< "Please try again with a working filename";
}
*/
return 0;

}

