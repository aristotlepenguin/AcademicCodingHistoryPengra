//
//DANIEL PENGRA
//CSC 354- Werpy
//11/16/17- DUE 11/16/17
//ASSIGNMENT 4- Assembler Pass 2
//
//DESCRIPTION
// This program is designed to process and produce intermediate files for an SIC/XE
//program. In addition to preparing this file, additional preparations for the second pass of this
//program are completed, such as inserting needed symbols into a symbol table, inserting literals in a similar way,
//designating a base address, and displaying errors in the current program structure.
//The input file is designated by the user, and the output file is the name of the input file with
//the extension .int.
//
//After the program is passed once, it will use the intermediate file to pass through the program again.
//This time, it will calculate the object code and place it alongside each line of code.
//This will happen in a new file with the suffix .lst. In addition, it will
//generate an object file with the suffix .obj and input object code inside.
//
//g++ main.cpp expressioneval.cpp expressioneval.h symboltable.cpp symboltable.h assembler.cpp assembler.h
//NOTE: Make sure the included files are put in the same folder as the source code for this program.


#ifndef EXPRESSIONEVAL_H
#define EXPRESSIONEVAL_H
#include "symboltable.h"

struct ExpressionType{
char symbol[100];
char litText[100];
bool rflag;
int value;
bool iflag;
bool mflag;
int litLength;
}; //

struct NodeTypeS;//small node type

typedef NodeTypeS*PointerTypeS;

struct NodeTypeS{
char literal[100];
PointerTypeS next;
};

struct NodeTypeE;

typedef NodeTypeE* PointerTypeE;

struct NodeTypeE{
    ExpressionType element;
    PointerTypeE next;
};
struct dispShell{
char symbol[20];
int value;
bool relocatable;
bool direct;
bool indirect;
bool immediate;
bool indexed;
bool success;
};

class pengrad2
{
    public:
        pengrad2();
        virtual ~pengrad2();
        PointerTypeE theHead;
        PointerTypeE lHead;
        int entryCounter;
        PointerTypeE search(ExpressionType, bool);
        void view();
        dispShell evalTree(char[]);
        bool stringNumC (char[]);
        int litCount;
        void litView();
        BSTreeType x;
        void literal(const char[]);
        PointerTypeE litReturn(const char[]);
        //bool isSymbol(const char[]);
    protected:

    private:

        void insert(const ExpressionType);
        bool isSymbol(const char[], char='\0');

};
#endif
