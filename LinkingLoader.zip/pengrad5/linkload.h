#ifndef LINKLOAD_H
#define LINKLOAD_H
#include <string>
#include <fstream>
using namespace std;

struct sym;
typedef sym* pointSym;
struct sym{
string name;
pointSym next;
int loc;
};

struct inp;
typedef inp* pointInp;
struct inp{
fstream stream;
pointInp next;
int endMark;
int startMark;
};

class linkload{

public:
linkload(int, char**);
~linkload();
//void readArgs(int, char**);
int fileNum;
string whole;
ofstream mem;
fstream pass2;
pointSym symHead;
void headHand(string);
void texHand(string);
void endHand(string);
void defHand(string);
void modCleanup();
void disp();
string collect(string);
void arrangeFile(int, char**);
string eliminate(string);
pointInp theHead;
int currentAmount;

};

#endif //LINKLOAD_H
