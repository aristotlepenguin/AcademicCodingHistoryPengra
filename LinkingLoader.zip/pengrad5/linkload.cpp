#include "linkload.h"
#include <iostream>
#include <iomanip>
#include <cstring>
#include <string>
#include <cstdlib>
#include <sstream>
using namespace std;

linkload::linkload(int num, char** args){

mem.open("memory.txt");
theHead=NULL;
symHead=NULL;
fileNum=0;
currentAmount=0;
pass2.open("pass2.txt", fstream::out);
whole="";
cout<<"ADDR\t0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F\n";
mem <<"ADDR\t0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F\n";

arrangeFile(num, args);

pointInp navPtr=theHead;
string lineOne;
while(navPtr!=NULL){

while(!navPtr->stream.eof()){
getline(navPtr->stream, lineOne);
if(lineOne[0]=='H'){
headHand(lineOne);

}
else if(lineOne[0]=='D'){

defHand(lineOne);
}
else if(lineOne[0]=='M'){

pass2<<lineOne<<endl;


}
else if(lineOne[0]=='T'){
texHand(lineOne);


}
else if(lineOne[0]=='E'){
endHand(lineOne);

}
else if(lineOne[0]=='R'){


}

}
navPtr=navPtr->next;
}

pass2.close();
if(num>1){
modCleanup();

disp();
}
}


linkload::~linkload(){
mem.close();
pass2.close();
pointSym nav2;
pointSym prev2;
nav2=symHead;

while (nav2!=NULL){

prev2=nav2;
nav2=nav2->next;

delete prev2;


}


pointInp navPtr;
pointInp prevPtr;
navPtr=theHead;


while (navPtr!=NULL){

prevPtr=navPtr;
navPtr=navPtr->next;
prevPtr->stream.close();
delete prevPtr;


}
return;
}

void linkload::arrangeFile(int argc, char** argv){

pointInp navPtr;
navPtr=theHead;

for(int p=1; p<argc; p++){

if(navPtr==NULL){
theHead=new (std::nothrow) inp;

navPtr=theHead;
}
else{

navPtr->next=new (std::nothrow) inp;
navPtr=navPtr->next;

}
navPtr->stream.open(argv[p]);
navPtr->startMark=0;
navPtr->endMark=0;
navPtr->next=NULL;


}

}

void linkload::headHand(string line){

int start=0;

pointInp navPtr;

navPtr=theHead;

start=currentAmount;

string value;

line=eliminate(line);


value=collect(line);

pointSym draftH;
draftH=symHead;
while (1){
if(symHead==NULL){

symHead=new (std::nothrow)sym;
symHead->loc=currentAmount;
symHead->name=value;
symHead->next=NULL;
break;
}
else if(draftH->next==NULL){
draftH->next=new (std::nothrow)sym;
draftH=draftH->next;
draftH->loc=currentAmount;
draftH->name=value;
draftH->next=NULL;
break;
}
else{draftH=draftH->next;}

}



line=eliminate(line);
line=eliminate(line);

value=collect(line);

navPtr=theHead;
for (int l=0; l!=fileNum; l++){
navPtr=navPtr->next;

}

navPtr->endMark=(strtol(value.c_str(), NULL, 16))+start;
navPtr->startMark=start;


for (int q=0; q<((navPtr->endMark)-(navPtr->startMark)); q++){
whole+= "XX";
}



}


void linkload::texHand(string line){
string value;
int placer=0;
line=eliminate(line);
value=collect(line);
placer=(strtol(value.c_str(), NULL, 16)*2);
placer=placer+currentAmount;

line=eliminate(line);
line=eliminate(line);

while (line!=""){
value=collect(line);
line=eliminate(line);

for(unsigned int q=0; q<value.length(); q++){

whole[placer]=value[q];
placer++;
}

}
}


string linkload::collect(string coll){

string newOne="";
for(unsigned int i=0; coll[i]!='^' && i<coll.length() && coll[i]!=' '; i++){

newOne+=coll[i];
}
return newOne;
}


string linkload::eliminate(string elim){

while(elim[0]!='^' && elim!=""){
	elim.erase(0,1);

}
elim.erase(0,1);
return elim;
}


void linkload::endHand(string){
pointInp navPtr;
navPtr=theHead;
int deb=0;
while(navPtr->next!=NULL && deb<fileNum){
    navPtr=navPtr->next;
    deb++;

}


currentAmount = (navPtr->endMark*2);
pass2<<"END"<<endl;
fileNum++;
}

void linkload::defHand(string line){
string name;
string loc;
line= eliminate(line);
while(line != ""){


name=collect(line);
line=eliminate(line);
loc=collect(line);
line=eliminate(line);

pointSym draftH;
draftH=symHead;
while (1){
if(symHead==NULL){

symHead=new (std::nothrow)sym;
symHead->loc=(strtol(loc.c_str(), NULL, 16)*2)+currentAmount;
symHead->name=name;
symHead->next=NULL;
break;
}
else if(draftH->next==NULL){
draftH->next=new (std::nothrow)sym;
draftH=draftH->next;
draftH->loc=(strtol(loc.c_str(), NULL, 16)*2)+currentAmount;
draftH->name=name;
draftH->next=NULL;
break;
}
else{draftH=draftH->next;}

}



}

return;
}

void linkload::modCleanup(){
int offset=8560;
int locator=0;
string line;
string value;
pass2.open("pass2.txt", fstream::in);

pointInp navPtr;
navPtr=theHead;

pointSym nav2;


while (!pass2.eof()){
getline(pass2, line);
if(line=="END"){
    if(navPtr->next==NULL){
        break;
    }
    else{
        navPtr=navPtr->next;
        continue;
    }

}
line=eliminate(line);

value=collect(line);
locator=(navPtr->startMark)+(strtol(value.c_str(), NULL, 16)*2);

line=eliminate(line);
value=collect(line);
int digits= strtol(value.c_str(), NULL, 16);
if(digits%2){
    locator++;
}
line=eliminate(line);
value=collect(line);
if(line[0]=='+'){
  value.erase(0,1);
  nav2=symHead;
  while (nav2!=NULL)
  {
      if(nav2->name==value){
        break;
      }
        nav2=nav2->next;
  }

  string found="";
  for(int y=0; y<digits; y++){
    found+=whole[locator+y];
  }

  offset=offset+((nav2->loc)/2) + strtol(found.c_str(), NULL, 16);


  stringstream toHexStr;
  toHexStr<<setw(digits)<<setfill('0')<<hex<<offset;

  for(int w=0; w<digits; w++){
   whole[locator+w] = toHexStr.str()[w];

  }


}
else if(line[0]=='-'){
    value.erase(0,1);
  value.erase(0,1);
  nav2=symHead;
  while (nav2!=NULL)
  {
      if(nav2->name==value){
        break;
      }
        nav2=nav2->next;
  }

  string found="";
  for(int y=0; y<digits; y++){
    found+=whole[locator+y];
  }

  offset= strtol(found.c_str(), NULL, 16) - (offset+((nav2->loc)/2));


  stringstream toHexStr;
  toHexStr<<setw(digits)<<setfill('0')<<hex<<offset;

  for(int w=0; w<digits; w++){
   whole[locator+w] = toHexStr.str()[w];

  }

}


offset=8560;
}

}


void linkload::disp(){
    cout<<"2170\t";
    mem<<"2170\t";
    int lineCt=0;
for(unsigned int x=0; x<whole.length() && x<104; x++){
  cout<<whole[x];
  mem<<whole[x];
  if((x%2)){
    cout<<"   ";
    mem<<"   ";
  }
  if((x==31)||(x==63) || (x==95)){
        lineCt++;
    cout<<hex<<endl << 8560+(16*lineCt) << "\t";
    mem<<hex<<endl << 8560+(16*lineCt) << "\t";

  }


}


}
