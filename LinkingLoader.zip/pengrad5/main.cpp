#include <iostream>
#include <string>
#include <cstring>
#include "linkload.h"

using namespace std;

int main(int argc, char* argv[]){

linkload s(argc, argv);



return 0;
}
