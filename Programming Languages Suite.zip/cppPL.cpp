 /*DAN PENGRA
 CSC 461-S01- Assignment 1
 Due 1/26/18
 FORTRAN Version
 Descripton: This program is the Fortran code for a
 program that begins by inputting ten integers.
 These integers are then tested for their divisibility
 with 3 values, the sum of digits, the positive square root,
 and whether they are prime numbers. After this, two arrays of
 type real are bubble sorted and merged.
*/

#include <iostream>
#include <cmath>
using namespace std;

void multipleVal(int);
void digSum(int);
void posSqRt(int);
void isPrime(int);
void bubbleSort(float[], const int);
void arraySorter(float[],float[], const int, const int);


int main(){
//Variable Table
//input- Input array for the code
//lhs, rhs- Float arrays that are sorted and merged
//array1, array2- Array sizes


int input[10];
    input[0]=3;
    input[1]=104;
    input[2]=3773;
    input[3]=13;
    input[4]=121;
    input[5]=77;
    input[6]=30751;
    input[7]=1233222;
    input[8]=348373443;
    input[9]=878;


for(int r=0; r<10; r++){

    multipleVal(input[r]);
    digSum(input[r]);
    posSqRt(input[r]);
    isPrime(input[r]);

}


const int array1=5;
const int array2=5;
float lhs[array1];
float rhs[array2];
    lhs[0]=1;
    lhs[1]=3;
    lhs[2]=5;
    lhs[3]=7;
    lhs[4]=9;

    rhs[0]=10;
    rhs[1]=4;
    rhs[2]=6;
    rhs[3]=8;
    rhs[4]=2;


bubbleSort(lhs, array1);
bubbleSort(rhs, array2);
arraySorter(lhs, rhs, array1, array2);


return 0;}

/* SUBROUTINE 1: DIVISIBILITY VALUES
 Description: This function tests divisibility
 of an input integer with 7, 11, and 13.
 The user sees this in screen output.
 Passed in: test*/

void multipleVal(int test){
//Variable Table
//test- Value being tested

    if((test%7==0)||(test%11==0)||(test%13==0)){

        cout<<test << " is a multiple of 7, 11, or 13."<<endl;
    }
    else{
        cout<<test << " is not a multiple of 7, 11, or 13."<<endl;}

return;
}
/*
 SUBROUTINE 2:SUM OF DIGITS
 Description: This function tests the sum of
 an input integer's digits.
 The user sees this in screen output.
 Passed in: test3
*/
void digSum(int test){
//Variable Table
//test- Value being tested
//sum- Sum of the digits that gets incremented
    int sum=0;

    while (test!=0){
        sum=sum+(test%10);
        test=test/10;

    }
    cout<<"The sum of its digits is "<<sum << endl;
return;
}
 /*SUBROUTINE 3: SQUARE ROOT
 Description: This function tests the square root
 of an input integer.
 The user sees this in screen output.
 Passed in: test*/
void posSqRt(int test){
    //Variable Table
    //test- Value being tested
    //param- Value converted to double
    //lg- The last guess for the square root
    //ng- A new guess for the square root
    double param=test;
    double ng=1;
    double lg=0;

    while ((ng-lg)>0.005 || (ng-lg)<-0.005){
        lg=ng;
        ng=0.5*(lg+param/lg);
    }

    cout<<"Its positive square root is " << ng << endl;
return;
}

 /*SUBROUTINE 4: PRIME TEST
 Description: This function finds whether an
 input integer is prime.
 The user sees this in screen output.
 Passed in: test*/

void isPrime(int y){
    //Variable Table
    //y- Value being tested


    for(int w=2; w<y; w++){

    if(y%w==0){
        cout<<"It is not prime." << endl << endl;
        return;
    }

    }
    cout<<"It is prime."<<endl << endl;

return;
}

 /*SUBROUTINE 5: BUBBLE SORT
 Description: This function takes an array of float
 values and sorts them in ascending order
 Passed in: arr(array), dimen(the size of the array)*/

void bubbleSort(float lhs[], const int array1){

//Variable Table
//lhs- Input array
//array1- Array size
//sorted-Flag for a sorted array

bool sorted=0;
float place;
while (sorted==0){
        sorted=1;
    for(int r=1; r<array1; r++){
        if(lhs[r-1]>lhs[r]){
            place=lhs[r-1];
            lhs[r-1]=lhs[r];
            lhs[r]=place;
            sorted=0;
    }
    }

}

return;

}
 /*SUBROUTINE 6:ARRAY MERGE
 Description: This function takes two sorted arrays
 of real values and places them in a single ascending-order
 array.
 Passed in: lhs, rhs(arrays), array2, array1 (the sizes of each array)
 */
void arraySorter(float lhs[], float rhs[], const int array1, const int array2){
//Variable Table
//lhs, rhs- Input array
//array1, array2- Array size
//p, q- Counters for the arrays being merged
//z- Counter for the merged array

float fullArray[array1+array2];
int p=0;
int q=0;
int z=0;

	while (p<array1 || q<array2){

		if((p<array1 && lhs[p]<=rhs[q]) || q>=array2){
			fullArray[z]=lhs[p];
			p++; z++;
	}
		else{
			fullArray[z]=rhs[q];
			q++; z++;
		}
}

cout<<"Merged Array Order (ascending)" << endl;
for(int w=0; w<(array1+array2); w++){
  cout<<fullArray[w]<<endl;

}
return;
}
