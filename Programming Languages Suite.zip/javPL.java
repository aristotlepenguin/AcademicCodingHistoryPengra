 /*DAN PENGRA
 CSC 461-S01- Assignment 1
 Due 2/12/18
 Java Version
 Descripton: This program is the Java code for a
 program that begins by inputting ten integers.
 These integers are then tested for their divisibility
 with 3 values, the sum of digits, the positive square root,
 and whether they are prime numbers. After this, two arrays of
 type real are bubble sorted and merged.
*/
public class progLang {


public static void main(String []args){
   //Variable Table
   //intInput- Input data for the first section
   // lhs, rhs- Float arrays that are sorted and merged
   // r1, r2- Array sizes
   int r1=5;
    int r2=5;
    int [] intInput;
    intInput = new int[10];
    intInput[0]=3;
    intInput[1]=104;
    intInput[2]=3773;
    intInput[3]=13;
    intInput[4]=121;
    intInput[5]=77;
    intInput[6]=30751;
    intInput[7]=1233222;
    intInput[8]=348373443;
    intInput[9]=878;
    
    float [] lhs;
    float [] rhs;
    lhs= new float[r1];
    rhs= new float[r2];
    lhs[0]=1;
    lhs[1]=3;
    lhs[2]=5;
    lhs[3]=7;
    lhs[4]=9;
    rhs[0]=10;
    rhs[1]=8;
    rhs[2]=6;
    rhs[3]=4;
    rhs[4]=2;
    
    for(int z=0; z<10; z=z+1){
        multipleVal(intInput[z]);
        digSum(intInput[z]);
        posSqRt(intInput[z]);
         isPrime(intInput[z]);
         System.out.println("");
}
    bubbleSort(lhs, r1);
    bubbleSort(rhs, r2);
    arraySorter(lhs, rhs, r1, r2);
    
}
/* SUBROUTINE 1: DIVISIBILITY VALUES
 Description: This function tests divisibility
 of an input integer with 7, 11, and 13.
 The user sees this in screen output.
 Passed in: t*/
public static void multipleVal(int t){
	//Variable Table
	//t- Value being tested
	if(t%7==0)
		System.out.println(t + " is a multiple of 7, 11, or 13.");
	else if(t%11==0)
		System.out.println(t + " is a multiple of 7, 11, or 13.");	
	else if(t % 13==0)
		System.out.println(t + " is a multiple of 7, 11, or 13.");
}
  
  /*
 SUBROUTINE 2:SUM OF DIGITS
 Description: This function tests the sum of
 an input integer's digits.
 The user sees this in screen output.
 Passed in: t
*/
  public static void digSum(int t){
//Variable Table
//t- Value being tested
//test3- Duplicate of the variable test
//total- Total sum displayed to the user
   int test3=t;
   int total=0;
    
    while (test3!=0){
    	total=total+(test3 % 10);
    	test3=test3/10;}
    System.out.println("The sum of its digits is " + total );
    return;
  }
/*SUBROUTINE 3: SQUARE ROOT
 Description: This function tests the square root
 of an input integer.
 The user sees this in screen output.
 Passed in: t*/
  public static void posSqRt (int t){
	//Variable Table
    //t- Value being tested
    //lg- The last guess for the square root
    //ng- A new guess for the square root
  	double lg=0;
    double ng=1;
    
    while(((ng-lg)>0.005) || ((ng-lg)<-0.005)){
    	lg=ng;
      	ng=0.5*(lg+(t/lg));
    }
    System.out.println("Its square root is " + ng);
      return;
  }
  /*SUBROUTINE 4: PRIME TEST
 Description: This function finds whether an
 input integer is prime.
 The user sees this in screen output.
 Passed in: t*/
  public static void isPrime(int t){
	  //Variable Table
    //t- Value being tested
    for (int r=2; r<t; r=r+1){
      if((t%r)==0){
      	System.out.println("It is not prime.");
      	return;}
    }
    System.out.println("It is prime.");
    return;
  }
 /*SUBROUTINE 5: BUBBLE SORT
 Description: This function takes an array of float
 values and sorts them in ascending order
 Passed in: arr(array), dimen(the size of the array)*/
public static void bubbleSort(float[] arr, int dimen){
	//Variable Table
	//arr- Input array
	//dimen- Array size
	//sorted-Flag for a sorted array
	boolean sorted=true;
	float place=0;
		while(sorted==true){
			sorted=false;
			for(int x=1; x<dimen; x=x+1){
				if(arr[x-1]>arr[x]){
					place=arr[x];
					arr[x]=arr[x-1];
					arr[x-1]=place;
					sorted=true;
				}
			}
		}
	
	
	
	return;
}
 /*SUBROUTINE 6:ARRAY MERGE
 Description: This function takes two sorted arrays
 of real values and places them in a single ascending-order
 array.
 Passed in: lhs, rhs(arrays), s1, s2 (the sizes of each array)
 */
public static void arraySorter(float[] lhs, float[] rhs, int s1, int s2){
//Variable Table
//lhs, rhs- Input array
//s1, s2- Array size
//p, q- Counters for the arrays being merged
//z- Counter for the merged array
	int p=0;
	int q=0;
	int z=0;
	float [] total;
	total = new float[s1+s2];
		while(p<s1 || q<s2){
			if((p<s1 && lhs[p]<=rhs[q]) || (q>=s2)){
				total[z]=lhs[p];
				p=p+1;
				z=z+1;
			}
			else{
				total[z]=rhs[q];
				q=q+1;
				z=z+1;
				}
	
}
for (int g=0; g<(s1+s2); g=g+1){
    System.out.println(total[g]);
    
}

 
}}