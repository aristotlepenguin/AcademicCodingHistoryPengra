#DAN PENGRA
#CSC 461-S01- Assignment 2
#Python Version
#Due 2/12/18
#Descripton: This program is the Python code for a 
#program that begins by inputting ten integers. 
#These integers are then tested for their divisibility 
#with 3 values, the sum of digits, the positive square root,
#and whether they are prime numbers. After this, two arrays of 
#type real are bubble sorted and merged.

 #SUBROUTINE 1: DIVISIBILITY VALUES
 #Description: This function tests divisibility 
 #of an input integer with 7, 11, and 13.
 #The user sees this in screen output.
 #Passed in: test
def multipleval(test):
#Variable Table:
#test: the variable being tested
        if( (test%11)==0 ): print test , " is divisible by 11, 7, or 13."
        elif(test%7==0 ):print test , " is divisible by 11, 7, or 13."
        elif (test%13==0):print test , " is divisible by 11, 7, or 13."
        return
#SUBROUTINE 2:SUM OF DIGITS
#Description: This function tests the sum of 
#an input integer's digits.
#The user sees this in screen output.
#Passed in: test
def digSum(test):
#Variable Table
#test3: a duplicate of the original test variable
#test: the variable being tested
#total: The total displayed to the user 
		test3=test
		total=0
		while test3!=0:
			total=total + (test3 % 10)
			test3=test3/10
		print "The sum of its digits is ", total	
		return
#SUBROUTINE 3: SQUARE ROOT
#Description: This function tests the square root 
#of an input integer.
#The user sees this in screen output.
#Passed in: test
def posSqRt (test):
#Variable Table
#lg- The last guess for the square root
#ng- The next guess for the square root
#test- Variable being tested

		lg=0.0
		ng=1.0
		
		while ((ng-lg)>0.005) | ((ng-lg)<-0.005):
			lg=ng
			ng=0.5*(lg+(test/lg))
		
		print "Its positive square root is ",ng
		return
#SUBROUTINE 4: PRIME TEST
#Description: This function finds whether an 
#input integer is prime.
#The user sees this in screen output.
#Passed in: test
def isPrime(test):
#Variable Table 
#test- Variable being tested
		for g in range(2, test):
			if((test%g)==0):
				print "It is not prime."
				return
		print "It is prime."
		return
#SUBROUTINE 5: BUBBLE SORT
#Description: This function takes an array of float
#values and sorts them in ascending order
#Passed in: arr(array), dimen(the size of the array)
def bubbleSort(arr, dimen):
#Variable Table
#place- Placeholder for a bubble sort
#sorted- Boolean flag for a sorted array
#arr- Array being sorted
#dimen- Array size for arr
		place=0.0
		sorted=True
		
		while sorted:
			sorted=False
			for h in range(1, dimen):
				if(arr[h-1] > arr[h]):
					place=arr[h-1]
					arr[h-1]=arr[h]
					arr[h]=place
					sorted=True
		return
 #SUBROUTINE 6:ARRAY MERGE
 #Description: This function takes two sorted arrays 
 #of real values and places them in a single ascending-order
 #array.
 #Passed in: lhs, rhs(arrays), lval, rval (the sizes of each array)
 		
def arraySorter(lhs, rhs, lval, rval):
    q=0
    p=0
#lhs, rhs- Two arrays being sorted
#lval, rval- Array sizes
#p, q- Counter values for the two arrays
#total- Total value for the arrays
    total=[]
    while (p < lval) or (q < rval):
        
        if q >= rval:
            
            total.append(lhs[p])
            p=p+1  
        elif p<lval:
            if lhs[p]<=rhs[q]:
                total.append(lhs[p])
                p=p+1
            else:
                total.append(rhs[q])
                q=q+1
        else:
            total.append(rhs[q])
            q=q+1
    		
    for h in range(0, (lval+rval)):
        
        print total[h]
    return

#Variable Table
#inList- Input data for the first problem
#floatList1, floatList2- Input data for the second problem
inList = [3, 104, 3773, 13, 121, 77, 30751, 1233222, 348373443, 878]
floatList1 = [10.0, 8.0, 6.0, 4.0, 2.0]
floatList2 = [1.0, 3.0, 5.0, 7.0, 9.0]

for x in inList:
    multipleval(x)
    digSum(x)
    posSqRt(x)
    isPrime(x)
    print ""



bubbleSort(floatList1, len(floatList1))
bubbleSort(floatList2, len(floatList2))
arraySorter(floatList1, floatList2, 5, 5)
