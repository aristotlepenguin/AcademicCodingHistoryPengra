//
//DANIEL PENGRA
//CSC 300- GAMRADT
//2/28/17- Due 2/29/17
//ASSIGNMENT 3- Warrior Class
//
//DESCRIPTION
//This program's purpose is to
//establish and manage a character class
//from a fictional game franchise "Dragon
//Quest". The "Warrior" class
//holds a specific weapon, has one
//of two genders, and has a
//certain amount of life energy and
//damage resistance. These attributes
//can be seen/modified through the
//setters and getters in the Warrior
//class. The View class is responsible
//for designating a Warrior and
//showing it to the user.
#include "View.h"
#include <iostream>
#include <iomanip>
namespace CharacterNS{

//
//FUNCTION <View()>
//Description: Default constructor. The warrior class is
//set to the defaults. The Warrior constructor
//deals with everything, so there's no action in this one.
//Passed In:
//Passed Out:
//
View::View()
{

}
//
//FUNCTION <View(Warrior &newWarrior)>
//Description: Copy constructor. Pass in
//a warrior class to get a copy of that one,
//designated in the view.
//Passed In: &newWarrior
//Passed Out:
//
View::View(Warrior &newWarrior)
{
    refWarrior = newWarrior;
}
//
//FUNCTION <View()>
//Description: Copy constructor. Pass in
//a view class to get a copy of that one.
//Passed In: &copiedView
//Passed Out:
//
View::View(View &copiedView)
{
    refWarrior = copiedView.refWarrior;
}
//
//FUNCTION <~View()>
//Description: This destructor used std::cout
//to indicate a destroyed class instance to
//the user. The std directive is used instead of
//clarifying a namespace.
//Passed In:
//Passed Out:
//
View::~View()
{
     std::cout<<"View class instance destroyed.\n";
}
//
//FUNCTION <viewWarrior()>
//Description: Displays the set Warrior to the
//user in an easy-to-read manner. The iomanip
//library is used to position the text.
//Passed In:
//Passed Out:
//
void View::viewWarrior(){
int tester = 0;
std::cout<< std:: setw(12)<<"Class:" << std:: setw(12)<< "Warrior" << "\n";
std::cout<< std:: setw(12)<<"Gender:" << std:: setw(12);

tester = refWarrior.isGenderFemale();
if (tester == 0){std::cout << "Male" << "\n";}
else {std::cout << "Female" << "\n";}
tester = 0;

std::cout<< std:: setw(12)<<"Life Force:" << std:: setw(12)<<  refWarrior.getLifeForce() << "\n";
std::cout<< std:: setw(12)<<"Resistance:" << std:: setw(12)<< refWarrior.getResistance() << "\n";
std::cout<< std:: setw(12)<<"Weapon:" << std:: setw(12);

tester = refWarrior.getWeapon();
if (tester == 0){std::cout << "Dagger" << "\n";}
else if (tester == 1){std::cout<< "Mace" << "\n";}
else {std::cout << "Sword" << "\n";}
tester = 0;




}
}
