//
//DANIEL PENGRA
//CSC 300- GAMRADT
//2/28/17- Due 2/29/17
//ASSIGNMENT 3- Warrior Class
//
//DESCRIPTION
//This program's purpose is to
//establish and manage a character class
//from a fictional game franchise "Dragon
//Quest". The "Warrior" class
//holds a specific weapon, has one
//of two genders, and has a
//certain amount of life energy and
//damage resistance. These attributes
//can be seen/modified through the
//setters and getters in the Warrior
//class. The View class is responsible
//for designating a Warrior and
//showing it to the user.
#ifndef VIEW_H
#define VIEW_H
#include "Warrior.h"
namespace CharacterNS{

class View
{
    public:
//
//FUNCTION <View()>
//Description: Default constructor. The warrior class is
//set to the defaults.
//Passed In:
//Passed Out:
//
        View();
//
//FUNCTION <View(Warrior &newWarrior)>
//Description: Copy constructor. Pass in
//a warrior class to get a copy of that one,
//designated in the view.
//Passed In: &newWarrior
//Passed Out:
//
        View(Warrior &newWarrior);
//
//FUNCTION <View()>
//Description: Copy constructor. Pass in
//a view class to get a copy of that one.
//Passed In: &copiedView
//Passed Out:
//
        View(View &copiedView);
//
//FUNCTION <~View()>
//Description: This destructor used std::cout
//to indicate a destroyed class instance to
//the user.
//Passed In:
//Passed Out:
//
        ~View();
//
//FUNCTION <setWarrior(Warrior &newWarrior)>
//Description: Sets the Warrior class parameters to
//match the one passed in.
//Passed In: &newWarrior
//Passed Out:
//
      inline void setWarrior(Warrior &newWarrior){refWarrior = newWarrior;}
//
//FUNCTION <viewWarrior()>
//Description: Displays the set Warrior to the
//user in an easy-to-read manner.
//Passed In:
//Passed Out:
//
        void viewWarrior();
    protected:
    private:
        Warrior refWarrior;
};

#endif // VIEW_H
}
