//
//DANIEL PENGRA
//CSC 300- GAMRADT
//2/28/17- Due 2/29/17
//ASSIGNMENT 3- Warrior Class
//
//DESCRIPTION
//This program's purpose is to
//establish and manage a character class
//from a fictional game franchise "Dragon
//Quest". The "Warrior" class
//holds a specific weapon, has one
//of two genders, and has a
//certain amount of life energy and
//damage resistance. These attributes
//can be seen/modified through the
//setters and getters in the Warrior
//class. The View class is responsible
//for designating a Warrior and
//showing it to the user.
#include "Warrior.h"
#include <iostream>
namespace CharacterNS{

//
//FUNCTION <Warrior()>
//Description: Establishes a new Warrior class with the
//default settings. lifeForce is 150, resistance is 25,
//gender is male, and the weapon is a sword.
//Passed In:
//Passed Out:
//
Warrior::Warrior()
{
lifeForce=150;
resistance=25;
gender=MALE;
weapon=SWORD;
}
//
//FUNCTION <Warrior(Warrior &copiedWarrior)>
//Description: The constructor directly accesses the
//passed in class, setting the new attributes to
//the old ones.
//Passed In: copiedWarrior
//Passed Out:
//
Warrior::Warrior(Warrior &copiedWarrior)
{
    gender=copiedWarrior.gender;
    lifeForce=copiedWarrior.getLifeForce();
    resistance=copiedWarrior.getResistance();
    weapon=copiedWarrior.getWeapon();

}

//
//FUNCTION <~Warrior()>
//Description: Indicates that an instance of
//the class has been destroyed. The cout
//syntax is std::cout, where no standard
//namespace is used.
//Passed In:
//Passed Out:
//
Warrior::~Warrior()
{
    std::cout<<"Warrior class instance destroyed.\n";
}
}
