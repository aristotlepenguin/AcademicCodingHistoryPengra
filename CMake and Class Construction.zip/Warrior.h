//
//DANIEL PENGRA
//CSC 300- GAMRADT
//2/28/17- Due 2/29/17
//ASSIGNMENT 3- Warrior Class
//
//DESCRIPTION
//This program's purpose is to
//establish and manage a character class
//from a fictional game franchise "Dragon
//Quest". The "Warrior" class
//holds a specific weapon, has one
//of two genders, and has a
//certain amount of life energy and
//damage resistance. These attributes
//can be seen/modified through the
//setters and getters in the Warrior
//class. The View class is responsible
//for designating a Warrior and
//showing it to the user.
#ifndef WARRIOR_H
#define WARRIOR_H
//#include <cstdbool>
namespace CharacterNS{



 enum WeaponType {DAGGER, MACE, SWORD};
class Warrior
{
    public:
//
//FUNCTION <Warrior()>
//Description: Default constructor, sets all
//attributes to their defaults.
//Passed In:
//Passed Out:
//
        Warrior();
//
//FUNCTION <Warrior(Warrior copiedWarrior)>
//Description: Initialize the class by passing in
//another class to create a copy of the original.
//Passed In: copiedWarrior
//Passed Out:
//
        Warrior(Warrior &copiedWarrior);
//
//FUNCTION <~Warrior()>
//Description: Indicates that an instance of
//the class has been destroyed.
//Passed In:
//Passed Out:
//
        ~Warrior();
//
//FUNCTION <getWeapon()>
//Description: Returns the warrior's weapon.
//Passed In:
//Passed Out: WeaponType
//
      inline  WeaponType getWeapon(){return weapon;}
//
//FUNCTION <setWeapon(WeaponType weapon)>
//Description: Sets the warrior's weapon.
//Passed In:  newWeapon
//Passed Out:
//
      inline  void setWeapon(WeaponType newWeapon){weapon = newWeapon;}
//
//FUNCTION <getLifeForce()>
//Description: Returns the warrior's current life force.
//Passed In:
//Passed Out: short int
//
       inline short int getLifeForce(){return lifeForce;}
//
//FUNCTION <setLifeForce(short int newLifeForce)>
//Description: Sets the warrior's current life force.
//Passed In: newLifeForce
//Passed Out:
//
      inline  void setLifeForce(short int newLifeForce){lifeForce=newLifeForce;}
//
//FUNCTION <getResistance()>
//Description: Returns the warrior's current resistance
//Passed In:
//Passed Out: unsigned short int
//
       inline unsigned short int getResistance(){return resistance;}
//
//FUNCTION <setResistance(unsigned short int newResistance)>
//Description: Sets the warrior's current resistance
//Passed In: newResistance
//Passed Out:
//
       inline void setResistance(unsigned short int newResistance){resistance=newResistance;}
//
//FUNCTION <isGenderMale()>
//Description: Designates whether the gender is  male.
//Passed In:
//Passed Out: bool
//
        bool isGenderMale(){return (gender==MALE);}
//
//FUNCTION <isGenderFemale()>
//Description: Designates whether the gender is  female.
//Passed In:
//Passed Out: bool
//
        bool isGenderFemale(){return gender==FEMALE;}
//
//FUNCTION <setGenderMale()>
//Description: Sets the gender to male.
//Passed In:
//Passed Out: bool
//
        void setGenderMale(){gender=MALE; return;}
//
//FUNCTION <setGenderFemale()>
//Description: Sets the gender to female.
//Passed In:
//Passed Out: bool
//
        void setGenderFemale(){gender=FEMALE; return;}
        WeaponType weapon;
    protected:
    private:
        enum GenderType {MALE, FEMALE};
        GenderType gender;
        short int lifeForce;
        unsigned short int resistance;

};
}
#endif // WARRIOR_H